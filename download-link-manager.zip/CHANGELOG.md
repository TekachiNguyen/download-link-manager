# Changelog

## Version 2.0.0 - 2024-01-15

### Thêm mới
- ✨ Hệ thống quản lý link tải về
- ✨ Trang đếm ngược với animation
- ✨ Quản lý quảng cáo 6 vị trí
- ✨ Thống kê lượt tải chi tiết
- ✨ Shortcode dễ sử dụng
- ✨ Responsive mobile

### Cải thiện
- ⚡ Tối ưu hiệu suất
- 🎨 Giao diện đẹp mắt

### Sửa lỗi
- 🐛 Không có (phiên bản đầu tiên)