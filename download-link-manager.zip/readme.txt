=== Download Link Manager ===
Contributors: Đạt Nguyễn (DeeAyTee)
Tags: download, manager, countdown, ads
Requires at least: 6.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 2.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Quản lý link tải về chuyên nghiệp với tính năng đếm ngược và gắn quảng cáo.

== Description ==

Đây là plugin giúp bạn quản lý các file tải về... (Viết mô tả dài ở đây)

== Installation ==

1. Upload thư mục plugin vào `/wp-content/plugins/`.
2. Kích hoạt plugin trong menu Plugins của WordPress.

== Changelog ==

= 2.0.1 =
* Thêm tính năng tự động cập nhật từ GitHub.
* Cập nhật thông tin bản quyền.

== Copyright ==

Copyright 2026 Đạt Nguyễn (DeeAyTee).
This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.